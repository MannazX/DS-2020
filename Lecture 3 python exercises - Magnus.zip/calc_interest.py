def CalcInterest(balance, rate):
	interest = balance * (rate * 0.01)
	return interest

def test(amount, rate):
	amount = amount + CalcInterest(amount, rate)
	print(amount)

test(1000, 5)

#To fix the error in the script it is necessary to make the function return the intereest otherwise the function gives no output.
