import math

x1 = 0
y1 = 0
x2 = 1
y2 = 1

def norm(x1, x2, y1, y2):
	xdist = x2 - x1
	ydist = y2 - y1
	norm = math.sqrt(xdist**2 + ydist**2)
	return norm

print("The distance between the two points is {:.2f}".format(norm(x1, x2, y1, y2)))
