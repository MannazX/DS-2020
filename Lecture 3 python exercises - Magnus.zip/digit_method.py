num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
num3 = int(input("Enter third number: "))

def sum_digit(num1, num2, num3):
	"""returns the number of digits in the sum."""
	sigma = num1 + num2 + num3
	str_sigma = str(sigma)
	digits = len(str_sigma)
	print("The number of digits in the sum is {:}".format(digits))
	return digits

sum_digit(num1, num2, num3)