num1 = eval(input("Enter first number: "))
num2 = eval(input("Enter second number: "))
num3 = eval(input("Enter third number: "))

def sum_and_mean(num1, num2, num3):
	"""returns the sum and mean of the three numbers."""
	sigma = num1 + num2 + num3
	mu = sigma/3
	print("The sum is {:}".format(sigma))
	print("The mean is {:.2f}".format(mu))
	return sigma, mu

sum_and_mean(num1, num2, num3)