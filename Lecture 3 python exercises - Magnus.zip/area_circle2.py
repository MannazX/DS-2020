import math
from math import pi

x2 = 1
y2 = math.sqrt(3)

def radius(x1, x2, y1, y2):
	xdist = x2 - x1
	ydist = y2 - y1
	norm = math.sqrt(xdist**2 + ydist**2)
	return norm

r = radius(0, x2, 0, y2)

def area(r):
	return pi*r**2

A = area(r)

print("The area of the circle with radius {:.2f} is {:.2f}".format(r,A))
