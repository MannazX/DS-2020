def calcInterest(balance, rate):
	interest = balance * (rate * 0.01)
	print('interest is', interest)
	return interest

interest = 40
print('interest is', interest)
calcInterest(1000, 5)
print('interest is', interest)

#The variable is printed three times.
#The function returns prints 50.0.
#The variable returns 40.
