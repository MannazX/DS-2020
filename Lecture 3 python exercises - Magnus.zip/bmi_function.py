def bmi(weight, height):
	"""returns the bmi of a person."""
	return weight/(height**2)

weight = eval(input("Type weight of person [kg] here: ")) 
height = eval(input("Type height of person [m] here: "))
BMI = bmi(weight, height)

print("The BMI of the person is {:.1f}".format(BMI))