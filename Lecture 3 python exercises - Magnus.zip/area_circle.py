from math import pi

r = eval(input("Enter the radius of the circle: "))

def area(r):
	"""returns the area of a circle."""
	area = pi*r**2
	return area

print("The area of the circle is {:.2f}".format(area(r)))