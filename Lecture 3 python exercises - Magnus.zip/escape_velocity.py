import math

M = 5.9742E24 #mass of Earth in kg
r = 6378.1 #radius of Earth in km
G = 6.67E-11 #Universal gravitation constant

def escape_velocity(M, r, G):
	return math.sqrt(2*G*M/r)

v_e = escape_velocity(M, r, G)

print("The velocity required to escape Earths gravitational pull is {:.2f} km/s".format(v_e))

