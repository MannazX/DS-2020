def calcInterest(balance, rate):
	interest = balance * (rate * 0.01)
	return interest

def test(amount, rate):
	amount = amount + calcInterest(amount, rate)
	print(amount)

test(1000, 5)

#To fix the error in the script it is necessary to switch the variable interest for the function (making sure it returns an output), because the variable interest is not a defined variable in the function.
