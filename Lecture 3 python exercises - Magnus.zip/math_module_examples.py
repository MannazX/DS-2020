import math
from math import e

print(math.factorial(6))
print(math.sqrt(9))
print(math.log(e))
print(math.log10(10))
print(math.log2(2))
print(math.gcd(8,4))
