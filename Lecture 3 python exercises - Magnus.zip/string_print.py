#def stringPrints(theString):
#	print('got:', theString)
#	theString = 'in a kingdom by the sea'
#	print('set to:', theString)

#outerString = 'It was many years ago'
#print('before, outer_string:', outerString)
#stringPrints(outerString)
#print('after, outer_string:', outerString)

#The output of this snippet is prints variable outerString with strings 'before and after outerString', before and after the function output.

def stringPrints(theString):
    print('got:', theString)
    theString = 'In a kingdom by the sea'
    print('set to:', theString)
    return theString

outerString = 'It was many years ago'
print('before, outer_string:', outerString)
outerString = stringPrints(outerString)
print('after, outer_string:', outerString)

#The outputs of the snippets do not differ in anyway other than this snippet returns the value of theString, but it is not used in the function below.
