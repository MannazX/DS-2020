string = "I hate aardvarks"

def replace_string(string):
	new_string = string.replace("a", "4")
	print(new_string)

replace_string(string)
