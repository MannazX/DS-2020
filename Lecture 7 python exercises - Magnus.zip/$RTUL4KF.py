string = "What Is Love"

def swap_string(string):
	new_string = string.swapcase()
	print(new_string)

swap_string(string)
