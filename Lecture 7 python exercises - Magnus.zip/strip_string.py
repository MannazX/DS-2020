string = "Baby, don't hurt me   "

def strip_string(string):
	new_string = string.strip()
	print(new_string)

strip_string(string)
