string = "I am 54 years old!"


def replace_alph(string):
	new_text = []
	for i in range(len(string)):
		letter = string[i]
		if letter.isalpha():
			letter = "*"
		new_text = new_text + [letter]

	new_text = "".join(new_text)
	print(new_text)

replace_alph(string)
