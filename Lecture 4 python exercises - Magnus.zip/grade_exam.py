exam_score = eval(input("Enter the score of the exam: "))

def exam_grade(score):
	if score >= 90:
		print("The exam grade is A")
	elif 89 >= score >= 80:
		print("The exam grade is B")
	elif 79 >= score >= 70:
		print("The exam grade is C")
	elif 69 >= score >= 60:
		print("The exam grade i s 0")
	else:
		print("The exam grade is F")

exam_grade(exam_score)