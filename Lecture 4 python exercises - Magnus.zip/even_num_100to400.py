def digits_even(N):
	def check_even(check):
		str_digits = str(N)
		first_digit = int(str_digits[0])
		if first_digit % 2 == 0:
			if len(str_digits) > 1:
				return check_even(str_digits[1:])
			else:
				#print(True)
				return True
		else:
			#print(False)
			return False

	return check_even(N)


for i in range(401):
    if i >= 100:
        print(i, digits_even(i))