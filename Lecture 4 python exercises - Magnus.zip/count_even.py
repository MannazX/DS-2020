number_list = [1,2,3,4,5,6,7,8,9]
even_list = []
def number_count(number_list):
	for numbers in number_list:
		if numbers % 2 == 0:
			even_list.append(numbers)
	print("The amount of even numbers in the list is {:}".format(len(even_list)))

number_count(number_list)

#i = 7
#def number_count(i, number_list):
#	even_list.append(number_list[i])
#	i = i - 2
#	if i < 1:
#		return False
#	return number_count(i, number_list)

#print(len(even_list))
#number_count(i, number_list)