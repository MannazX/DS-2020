datalist = [1452, 11.23, 1+2j, True, 'w3rsource', (0,-1), [5,12]]

i = len(datalist)
def list_read(datalist,i):
	print(datalist[-i], type(datalist[-i]))
	i = i - 1
	if i < 1:
		return False
	return list_read(datalist,i)

list_read(datalist,i)
