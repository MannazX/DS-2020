def bmi(weight, height):
	"""returns the bmi of a person."""
	return weight/(height**2)

def health_check(bmi):
	if bmi > 25:
		print("The person is above the healthy range - overweight")
	elif 25 >= bmi >= 19:
		print("The person is within the healthy range")
	elif bmi >= 19:
		print("The person is below the healthy range - underweight")

weight = eval(input("Type weight of person [kg] here: ")) 
height = eval(input("Type height of person [m] here: "))
BMI = bmi(weight, height)

health_check(BMI)

print("The BMI of the person is {:.1f}".format(BMI))