year = int(input("Enter the year here: "))

def leapyear(year):
	def check_leapyear(n_year):
		str_year = str(n_year)
		cent_year = int(str_year[0:1])*100
		dec_digts = int(str_year[2:])
		if cent_year % 400 == 0:
			return True
		elif dec_digts % 4 == 0:
			return True
		else:
			return False
	return check_leapyear(year)

print(leapyear(year))