def pattern(N):
	#Builds the initial pattern.
	for i in range(N):
		for j in range(i):
			print("* ", end="")
		print("")

	#Reverses the initial build process.
	for i in range(N,0,-1):
		for j in range(i):
			print("* ", end="")
		print("")

pattern(5)