n_list = [1,2,3,4,5,6]

def list_sum(n_list):
	n_sum = 0
	for n in n_list:
		n_sum += n
	return n_sum

print("The sum of the list is {:}".format(list_sum(n_list)))