n_list = [1,2,3,4,5,6]

def list_length(n_list):
	length = 0
	for i in n_list:
		length += 1
	return length

print("The number of items, or the 'length' of the list is {:}".format(list_length(n_list)))