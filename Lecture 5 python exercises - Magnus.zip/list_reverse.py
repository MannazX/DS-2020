n_list = [1,2,3,4,5,6]

def reverse(n_list):
	reverse_list = [n_list[n] for n in range(len(n_list)-1,-1,-1)]
	return reverse_list
print("The reverse of the number list is {:}".format(reverse(n_list)))