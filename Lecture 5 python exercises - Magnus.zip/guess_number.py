import random

random_number = random.randint(1,9) 
def guess_number(number):
	print("Guess the random number between 1 and 9.")
	attempt = 0
	guess = 0
	while guess != number:
		guess = int(input("Enter your guess here: "))
		if guess > number:
			attempt += 1
			print("The number is too large!")
		elif guess < number:
			attempt += 1
			print("The number is too small!")
		elif guess == number:
			attempt += 1
			print("Well guessed! you used {:} attempts".format(attempt))
	
guess_number(random_number)

