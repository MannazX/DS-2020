n_list = [1,2,10,4,5,6]

def max_element(n_list):
	max_item = n_list[0]
	for i in n_list:
		if i > max_item:
			max_item = i
	return max_item


print("The max element in the list is {:}".format(max_element(n_list)))